from __future__ import annotations

import json
import random
import typing
from random import Random
from typing import Callable, Literal, TypedDict


class PaymentSuccess(TypedDict):
    status: Literal["Success"]
    amount: int


class PaymentFailure(TypedDict):
    status: Literal["Failure"]
    reason: str | None


class PaymentCancelled(TypedDict):
    status: Literal["Cancelled"]


class PaymentReverted(TypedDict):
    status: Literal["Reverted"]
    amount: int


class RequestRejected(TypedDict):
    error_code: Literal["Rejected"]
    error: str


class TransactionNotFound(TypedDict):
    error_code: Literal["NotFound"]
    error: str


class InvalidAction(TypedDict):
    error_code: Literal["InvalidAction"]
    error: str


_previously_seen: dict[
    str, PaymentSuccess | PaymentFailure | PaymentCancelled | PaymentReverted
] = {}


class ConnectionLost(Exception):
    pass


def payment(amount: int, request_id: str) -> str:
    return json.dumps(_payment(amount, request_id))


def revert(request_id: str) -> str:
    return json.dumps(_revert(request_id))


def status(request_id: str) -> str:
    return json.dumps(_status(request_id))


def _payment(
    amount: int, request_id: str
) -> PaymentSuccess | PaymentFailure | PaymentCancelled | RequestRejected:
    global _previously_seen

    if request_id in _previously_seen:
        return {"error_code": "Rejected", "error": "action already performed"}

    result = _payment_result(amount, request_id)

    def side_effect() -> None:
        _previously_seen[request_id] = result

    _simulate_network_unreliability(side_effect)
    return result


def _payment_result(
    amount: int, request_id: str
) -> PaymentSuccess | PaymentFailure | PaymentCancelled:
    rng = Random(request_id)
    result = rng.choices(["Success", "Failure", "Cancelled"], weights=[8, 1, 1])[0]

    if result == "Success":
        return {"status": "Success", "amount": amount}
    elif result == "Failure":
        reason = rng.choice(["not enough balance", "card unsupported", None])
        return {"status": "Failure", "reason": reason}
    else:
        return {"status": "Cancelled"}


def _status(
    request_id: str,
) -> (
    PaymentSuccess
    | PaymentFailure
    | PaymentCancelled
    | PaymentReverted
    | TransactionNotFound
):
    global _previously_seen
    result = _previously_seen.get(request_id)
    _simulate_network_unreliability(lambda: None)
    if result is not None:
        return result
    else:
        return {"error_code": "NotFound", "error": "Transaction not found"}


def _revert(
    request_id: str,
) -> PaymentReverted | RequestRejected | TransactionNotFound | InvalidAction:
    global _previously_seen
    result = _previously_seen.get(request_id)
    side_effect = lambda: None
    return_val: PaymentReverted | RequestRejected | TransactionNotFound | InvalidAction
    if result is None:
        return_val = {"error_code": "NotFound", "error": "Transaction not found"}
    else:
        match result["status"]:
            case "Success":
                reversion: PaymentReverted = {
                    "status": "Reverted",
                    "amount": typing.cast(PaymentSuccess, result)["amount"],
                }
                return_val = reversion

                def side_effect() -> None:
                    _previously_seen[request_id] = reversion

            case "Reverted":
                return_val = {
                    "error_code": "Rejected",
                    "error": "action already performed",
                }
            case "Failure" | "Cancelled":
                return_val = {
                    "error_code": "InvalidAction",
                    "error": "Transaction can't be refunded as no payment took place",
                }

    _simulate_network_unreliability(side_effect)
    return return_val


def reset_service() -> None:
    global _previously_seen
    _previously_seen = {}


def _simulate_network_unreliability(
    side_effect: Callable[[], None], percent_chance: float = 5
) -> None:
    if random.randint(0, 99) < percent_chance:
        if random.choice([True, False]):
            side_effect()

        raise ConnectionError()
    else:
        side_effect()
